<?php
include 'includ/header.php';

// به‌روزرسانی API برای 3x-ui
$api_url = "http://localhost:54321/api";
$api_key = "your_api_key_here";

function sendRequest($endpoint, $data = []) {
    global $api_url, $api_key;
    $ch = curl_init("$api_url/$endpoint");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer $api_key"
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}
?>