<?php
include 'includ/header.php';

// دریافت سفارشات از 3x-ui
$orders = sendRequest("orders/list");

foreach ($orders as $order) {
    echo "کاربر: " . $order['user'] . "<br>";
    echo "حجم مصرفی: " . $order['used_traffic'] . "GB<br>";
    echo "وضعیت: " . $order['status'] . "<br><br>";
}
?>