<?php
include 'includ/header.php';

// دریافت لیست سرورها از 3x-ui
$servers = sendRequest("server/list");

foreach ($servers as $server) {
    echo "نام سرور: " . $server['remark'] . "<br>";
    echo "آدرس: " . $server['address'] . "<br>";
    echo "پورت: " . $server['port'] . "<br><br>";
}
?>